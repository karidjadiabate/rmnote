<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome for icons (if needed) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- pdf & excel -->
    <!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.0/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script src="{{ asset('frontend/dashboard/js/list.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('frontend/dashboard/css/dash.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/dashboard/html/admin.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/dashboard/css/lists.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/dashboard/css/messageError.css') }}">

    <title>Liste_des_sujet_corrigé</title>
    <style>
        .card1{
            box-shadow: none !important;
        }
        .btn-disabled{
            background-color: #D1D1D1;
        }
        .btn-select{
            background-color:#E7E5FF;
            color:#4A41C5;
        }
        .text-copie, .copy-counter, .copy-text{
            font-size: 1.2rem;
            color:#4A41C5;
        }
        .btn-select:hover{
            background-color:#4A41C5;
            color:#fff;
        }
        .selected.veil{
            position: absolute; 
            top: 0; left: 0; 
            width: 100%; 
            height: 100%; 
            background: #1D55FF57; 
            pointer-events: none;
        }
        .bar-white{
            background-color: #fff;
            margin-bottom: 1rem;
        }
        .bar-pupple{
            background-color: #4A41C5;
        }
        .alert-success{
            display:none;
           background-color:#06DB3F !important; 
           text-align:center;
           color: #fff;
           height:50px;
           width:100%;
        }
    </style>
</head>


<body>
    <!-- header -->
    @include('admin.include.menu')
    <div class="row">
         <div id="alert" class="alert alert-success">Dossier archivé !</div>
    </div>
    <!-- accueil -->
    <div class="container">
        <div class="printableArea">
            <h2 class="text-start">Liste des Etablissements</h2>
            <div class="d-flex justify-content-between align-items-center flex-wrap action-buttons mb-3 no-print">
                <div class="d-flex search-container">
                    <i class="fa fa-search"></i>
                    <input id="searchInput" type="text" id="search" class="form-control search-bar"
                        placeholder="Rechercher...">
                </div>

                <div class="d-flex justify-content-end flex-wrap action-buttons">
                    <button class="btn btn-disabled btn-imprimer" id="printBtn" onclick="printDiv()"><i
                            class="fa fa-print" disabled></i> Imprimer</button>

                    <button class="btn btn-custom btn-ajouter" data-bs-toggle="modal"
                        data-bs-target="#etablissementModal"  onclick="move()"><i class="fa fa-plus"></i> Terminer et archiver</button>
                </div> 
            </div>

            <div class="row mt-5">
            <div class="col-md-12 d-flex align-items-center justify-content-between bar-white" style="display:none">
                    <div id="myBar" class="bar-pupple" style="height:10px;width:0"></div>
            </div>
                <div class="col-md-6 d-none align-items-center justify-content-between btn-line">
                    <div class="text-center text-copie"> <span class="copy-counter">0</span> <span class="copy-text">Copie sélectionnée</span></div>
                    <div class="text-center"><button class="btn btn-select deselecttall">Déselectionner</button></div>
                    <div class="text-center"><button class="btn btn-select selectall">Tout Selectionner</button></div>
                </div>
            </div>

            <div class="row mt-5">
            <div class="col-sm-6 col-md-4 mb-2 sujet">
                <div class="card card1 rounded" style="position: relative; overflow: hidden;">
                    <img class="img-fluid" src="{{ asset('/assets/img/feuille.png') }}" alt="" srcset="" style="width: 100%; height: auto; display: block;">
                    <div class="selected"></div>
                </div>
            </div>

            <div class="col-sm-6 col-md-4 mb-2 sujet">
                <div class="card card1 rounded" style="position: relative; overflow: hidden;">
                    <img class="img-fluid" src="{{ asset('/assets/img/feuille.png') }}" alt="" srcset="" style="width: 100%; height: auto; display: block;">
                    <div class="selected"></div>
                </div>
            </div>

            <div class="col-sm-6 col-md-4 mb-2 sujet">
                <div class="card card1 rounded" style="position: relative; overflow: hidden;">
                    <img class="img-fluid" src="{{ asset('/assets/img/feuille.png') }}" alt="" srcset="" style="width: 100%; height: auto; display: block;">
                    <div class="selected"></div>
                </div>
            </div>
            
            <div class="col-sm-6 col-md-4 mb-2 sujet">
                <div class="card card1 rounded" style="position: relative; overflow: hidden;">
                    <img class="img-fluid" src="{{ asset('/assets/img/feuille.png') }}" alt="" srcset="" style="width: 100%; height: auto; display: block;">
                    <div class="selected"></div>
                </div>
            </div>
            
            <div class="col-sm-6 col-md-4 mb-2 sujet">
                <div class="card card1 rounded" style="position: relative; overflow: hidden;">
                    <img class="img-fluid" src="{{ asset('/assets/img/feuille.png') }}" alt="" srcset="" style="width: 100%; height: auto; display: block;">
                    <div class="selected"></div>
                </div>
            </div>           

            <div  class="col-sm-6 col-md-4 mb-2 sujet">
                <div class="card card1 rounded" style="position: relative; overflow: hidden;">
                    <img class="img-fluid" src="{{ asset('/assets/img/feuille.png') }}" alt="" srcset="" style="width: 100%; height: auto; display: block;">
                    <div class="selected"></div>
                </div>
            </div>

            </div>


        </div>
    </div>
    <!--  -->
    <!--  -->
    <!-- Modal -->

    <!--  -->


    <!---<script>
        document.addEventListener('DOMContentLoaded', function() {
            // Définir la configuration pour ce fichier
            setTableConfig({
                'Matière': 5, // Index de la colonne "Matière"
                'Classe': 6 // Index de la colonne "Classe"
            });

            // Définir l'ID du tableau pour les fonctions de recherche et de pagination
            setTableId('#etablissementTable');
            // Appel des fonctions de recherche et de pagination
            searchTable('#etablissementTable tbody', 'searchInput', 'noResults');
            paginateTable('#etablissementTable');
        });
    </script> -->


    </script>

    <!-- Bootstrap JS -->

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Select2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
   <script>
    $('.sujet').each(function(){
        $(this).on('click', function(){
            $('.btn-line').removeClass('d-none');
            $('.btn-line').addClass('d-flex');
            var parent = $(this).children('.card1');
            var children = parent.find('.selected');
            if(!children.hasClass('veil')){
                children.addClass('veil');
                counter = parseInt($('.copy-counter').text()) + 1;

            }else{
                children.removeClass('veil');
                counter = counter-1;
                counter = parseInt($('.copy-counter').text()) - 1;
            }
            if(counter == 0){
                $('.btn-line').addClass('d-none');
                $('.btn-line').removeClass('d-flex');
            }
            $('.copy-counter').text(counter);
        });


    });
    $('.selectall').on('click', function(){
        $('.btn-line').removeClass('d-none');
        $('.btn-line').addClass('d-flex');
        $('.selected').addClass('veil');
        var all = $('.selected').length;
        $('.copy-counter').text(all);
    });

    $('.deselecttall').on('click', function(){
        $('.btn-line').addClass('d-none');
        $('.btn-line').removeClass('d-flex');
        $('.selected').removeClass('veil');
        $('.copy-counter').text(0);
    });

    function move() {
    var bar =  document.querySelector('.bar-white');
    bar.style.display = "block";
    var elem = document.getElementById("myBar");   
    var msg = document.getElementById("alert");
    var width = 1;
    var id = setInterval(frame, 10);
    function frame() {
        if (width >= 100) {
        elem.style.display = "none"; 
        msg.style.display = "block";
        setTimeout(()=>{
            msg.style.display = "none";
        }, 2000);
        clearInterval(id);
        } else {
        width++; 
        elem.style.width = width + '%'; 
        }
    }
    }
   </script>


</body>

</html>
